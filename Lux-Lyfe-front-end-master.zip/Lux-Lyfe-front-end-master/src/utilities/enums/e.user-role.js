const eUserRole = {
  SUPER_ADMIN: "SUPER_ADMIN",
  ADMIN: "ADMIN",
  EMPLOYEE: "EMPLOYEE",
  GROCER: "GROCER",
  CUSTOMER: "CUSTOMER",
};

export default eUserRole;
